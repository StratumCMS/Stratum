@extends('theme::layout')

@section('title', 'Accueil')

@section('content')
    <h1>Bienvenue sur StratumCMS</h1>
    <p>Ceci est le thème par défaut activé automatiquement.</p>
@endsection
