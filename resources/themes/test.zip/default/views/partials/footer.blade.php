<footer style="background: #333; color: #fff; padding: 1rem; text-align: center;">
    <p>&copy; {{ date('Y') }} StratumCMS. Tous droits réservés.</p>
</footer>
