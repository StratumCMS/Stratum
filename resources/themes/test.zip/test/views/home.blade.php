@extends('theme::layout')

@section('title', 'Accueil')

@section('content')
    <h1 class="text-center p-6 text-2xl">Bienvenue sur StratumCMS</h1>
    <p class="text-center text-2xl">Ceci est le thème TEST.</p>
@endsection
