<header style="background: #333; color: #fff; padding: 1rem; text-align: center;">
    <h1>StratumCMS</h1>
    <nav>
        <a href="/" style="color: #fff; margin: 0 1rem; text-decoration: none;">Accueil</a>
        <a href="/about" style="color: #fff; margin: 0 1rem; text-decoration: none;">À propos</a>
    </nav>
</header>
